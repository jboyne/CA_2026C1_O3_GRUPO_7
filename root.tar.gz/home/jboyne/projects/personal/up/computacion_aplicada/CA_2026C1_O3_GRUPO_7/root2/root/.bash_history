history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamectl
sudo hostnamectl set-hostname TPServer
hostnamectl
cat /etc/os-release
setxkbmap us
sudo dpkg-reconfigure keyboard-configuration
sudo dpkg-reconfigure keyboard-configuration
sudo service keyboard-setup restart
sudo nano /etc/hosts
sudo vi /etc/hosts
sudo service keyboard-setup restart
sudo dpkg-reconfigure keyboard-configuration
sudo reboot
dpkg --get-selections > packages.txt
ls
cat packages.txt
less packages.txt
lsb_release -a
sudo apt update
ping 8.8.8.8
ping google.com
ip a
vi /etc/resolv.conf
ping 8.8.8.8
sudo apt update
nslookup google.com
ping google.com
sudo apt update
sudo vi /etc/apt/sources.list
sudo apt update
sudo apt update -y
sudo apt update
sudo apt upgrade -y
sudo apt --fix-missing upgrade -y
sudo apt full-upgrade -y
sudo apt autoremove -y
sudo reboot
sudo nano /etc/apt/sources.list
sudo vi /etc/apt/sources.list
sudo apt update
sudo vi /etc/apt/sources.list
sudo apt update
sudo apt upgrade --without-new-pkgs -y
sudo apt --fix-missing upgrade -y
sudo apt --fix-missing upgrade -y
sudo apt full-upgrade -y
sudo apt autoremove -y
sudo apt clean
sudo reboot
exit
ls
tar -xvzf Material_Adicional_TPVMCA.tar.gz
ls
cd Material_Adicional_TPVMCA/
ls
cat clave_privada.txt 
sudo cp index.php /var/www/html/
sudo cp logo.png /var/www/html/
sudo systemctl restart apache2
curl http://localhost
ip a
cat index.php
curl http://localhost/index.php
curl http://localhost/index
curl http://localhost
cd var
ls
cd ..
cd ..
cd var
ls
cd www
ls
sudo cp index.php /var/www/html/
cd 
ls
cd Material_Adicional_TPVMCA/
ls
sudo cp index.php /var/www/html/
cd /var
ls
cd www
ls
ls -lah
sudo cp index.php /var/www/html/
cd html
ls
mv index.html index.bak
ls
vi /etc/apache2/mods-enabled/dir.conf
vi /etc/apache2/mods-enabled/dir.conf
systemctl restart apache2
ls
cat index.php
curl http://localhost
curl http://localhost
ls -lah
ls -lah /var/www/html
systemctl status apache2 -no-pager
systemctl status apache2 --no-pager
curl http://localhost
curl http://TPServer
sudo apt install php libapache2-mod-php -y
sudo a2enmod php8.2
sudo systemctl restart apache2
curl http://localhost
curl http://localhost/index.php
curl http://localhost/index.php
echo '<?php phpinfo(); ?>'> /var/www/html/test.php
sudo apt update
sudo apt install mariab-server -y
sudo systemctl enable mariadb
sudo apt install mariadb-server -y
sudo shutdown
sudo systemctl enable mariadb
sudo systemctl start mariadb
sudo systemctl status mariadb
sudo mysql_secure_installation
ls
cd Material_Adicional_TPVMCA/
ls
sudo mysql_secure_installation
ls -lah
sudo mariadb < /root/Material_Adicional_TPVMCA/db.sql
cat /root/Material_Adicional_TPVMCA/db.sql 
sudo mariadb
ip a
ls
cat index.php 
less packages.txt
less index.php 
cat /root/Material_Adicional_TPVMCA/db.sql 
mariadb -u lcars -p ingenieria
mariadb -u lcars -p ingenieria
tail -50 /var/log/apache2/error.log
sudo apt install php-mysql -y
sudo systemctl restart apache2
ip a
ip a
sudo vi /etc/network/interfaces
sudo vi /etc/resolv.conf 
sudo systemctl  restart  networking
sudo reboot
ip a
ip route
ping 8.8.8.8
ping google.com
ping groftlres.com
lsblk
sudo reboot
lsblk
lsblk
fdisk /dev/sdc
lsblk
mkfs.ext4 /dev//sdc1
mkfs.ext4 /dev//sdc2
mkdir /www_dir
mkdir /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h
cp /var/www/html/index.php  /www_dir/
cp /var/www/html/logo.png  /www_dir/
cd /www_dir/
ls
cd ..
vi /etc/apache2/sites-enabled/000-default.conf 
vi /etc/apache2/apache2.conf 
systemctl restart apache2
vi /etc/apache2/apache2.conf 
vi /etc/apache2/apache2.conf 
systemctl restart apache2
blkid
vi /etc/fstab
blkid /dev/sdc1 /dev/sdc2
vi /etc/fstab
apt install build-essential dkms linux-headers-$(uname -r) -y
mkdir /mnt/cdrom
mount /dev/cdrom /mnt/cdrom
sh /mnt/cdrom/VBoxLinuxAdditions.run
sudo reboot
sudo apt install -y build-essential dkms linux-headers-$(uname -r)
sudo apt update
sudo apt install -y build-essential dkms linux-headers-$(uname -r)
sudo mount /dev/cdrom /mnt
sudo sh /mnt/VBoxLinuxAdditions.run
sudo reboot
exit
exit
exit
exit
exit
exit
sudo rebootexit
exit
exit
vi /etc/fstab
mount -a
systemctl daemon-reload
mount -a
df -h
lsblk
cat /proc/partitions
cd opt
cd opt
ls
cd ..
ls
cd opt
ls
cd particion
cd ..
cd proc
ls
cd partitions
cd partitions
cd partitions
cat partitions
cp /proc/partitions /opt/particion
cd ..
cd proc
ls
cd ..
cd opt
ls
cat particion 
cat /proc/partitions > /opt/particion
mkdir -p /opt/scripts
vi /opt/scripts/backup_full.sh
cd scripts
ls
./backup_full.sh --help
./backup_full.sh -help
ls
ls -l
chmod +x /opt/scripts/backup_full.sh
./backup_full.sh -help
./backup_full.sh /var/log /backup_dir
cd /backup_dir
ls
less log_bkp_20260526.tar.gz 
ls -l
./backup_full.sh /var/liog /backup_dir
cd /opt
ls
cd scripts/
l
ls
rm VBoxGuestAdditions-7.2.6
rm -f VBoxGuestAdditions-7.2.6
ls
cd ..
ls
rm VBoxGuestAdditions-7.2.6
rm -f VBoxGuestAdditions-7.2.6
rm -rf VBoxGuestAdditions-7.2.6
ls
cd scripts/
ls
./backup_full.sh /var/liog /backup_dir
/opt/scripts/backup_full.sh -help
/opt/scripts/backup_full.sh /www_dir /backup_dir
cd backup_dir
cd /backup_dir/
ls
crontab -e
crontab -l
ls -lah /backup_dir
crontab -lcd ..
cd 
ls
pwd
ls
rm packages.txt 
ls
cd /etc
ls
cd /opt
ls
cd /www_dir
ls
cd /backup_dir/
ls
cd /var
ls
