history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostnamectl
sudo hostnamectl set-hostname TPVMCA
hostnamectl
cat /etc/resolv.conf
vi /etc/resolv.conf
vi /etc/resolv.conf
cat /etc/apt/source.list
vi /etc/apt/source.list
sudo apt update
vi /etc/apt/source.list
sudo apt update
sudo nano /etc/apt/source.list
sudo vi /etc/apt/sources.list
sudo apt update
cat /etc/apt/sources.list
sudo vi /etc/apt/sources.list
vi /etc/apt/source.list
sudo vi /etc/apt/sources.list
sudo apt update
sudo apt upgrade -y
sudo apt upgrade --without-new-pkgs -y
sudo apt full-upgrade -y
sudo apt autoremove -y
sudo apt clean
cat /etc/hostname
cat /etc/hosts
sudo cat /etc/hosts
vi /etc/hosts
sudo apt update
sudo apt upgrade -y
sudo apt --fix-missing upgrade -y
sudo apt full-upgrade -y
sudo apt autoremove -y
sudo vi /etc/apt/sources.list
sudo apt update
sudo apt upgrade --without-new-pkgs -y
sudo apt full-upgrade -y
sudo apt autoremove -y
sudo apt clean
sudo reboot
cat /etc/os-release
ls
tar -xzf Material_Adicional_TPVMCA.tar.gz 
ls
cd Material_Adicional_TPVMCA/
ls
ls 'la /root/.ssh
ls -la /root/.ssh
mkdir -p /root/.ssh
chmod 700 /root/.ssh
localectl status
loadkey us
dpkg-reconfigure keyboard-configuration
systemctl restart keyboard-setup
loadkey us
reboot
ls
cd Material_Adicional_TPVMCA/
cat clave_publica.pub >> /root/.shh/authorized_keys
sudo cat clave_publica.pub >> /root/.shh/authorized_keys
mkdir -p /root/.ssh
chmod 700 /root/.ssh
sudo cat clave_publica.pub >> /root/.shh/authorized_keys
cat clave_publica.pub >> /root/.shh/authorized_keys
touch /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authoized_keys
chmod 600 /root/.ssh/authorized_keys
cat clave_publica.pub >> /root/.ssh/authorized_keys
ls -la /root/.ssh
cd .ssh
cd root
cd .ssh
cd /.ssh
cat /root/.ssh/authorized_keys 
sudo apt update
sudo apt install openssh-server -y
cd ..
sudo systemctl status ssh
sudo systemctl enable ssh
ip a
vi /etc/ssh/sshd_config
vi /etc/ssh/sshd_config
systemctl restart ssh
ip a
sudo apt update
sudo apt install apache2 -y
sudo apt install php libapache2-mod-php -y
php -v
sudo systemctl start apache2
systemctl status apache2
ls
cd Material_Adicional_TPVMCA/
cp index.php /var/www/html/
cp logo.png /var/www/html/
sudo apt update
sudo apt install mariadb-server -y
sudo systemctl enable mariadb
sudo systemctl start mariadb
sudo systemctl status mariadb
sudo mysql_secure_installation
sudo mariadb < /root/Material_Adicional_TPVMCA/db.sql
ls
sudo mariadb < /root/Material_Adicional_TPVMCA/db.sql
mariadb
sudo apt install php-mysql -y
sudo systemctl restart apache2
ip a
sudo vi /etc/network/interfaces
sudo vi /etc/resolv.conf
sudo systemctl restart networking
sudo reboot
ip a
ip route
ping -c 4 192.168.0.1
ip addr show enp0s3
ip route
ip a
systemctl status apache2
ss -tlnp | grep :80
ip a
cat /etc/network/interfaces
cat /etc/network/interfaces
vi /etc/network/interfaces
systemctl restart networking
lsblk
fdisk /dev/sdc
vi etc/fstab
blkid
vi /etc/fstab
blkid
vi etc/fstab
vi /etc/fstab
systemctl daemon-reload
mount -a
df -h
cat particion
/opt# cat particion
cat /proc/partitions > /opt/particion
mkdir -p /opt/scripts/backup_full.sh
chmod +x /opt/scripts/backup_full.sh
crontab -e
crontab -l
ls -lah /backup_dir
cd opt
cd /opt
ls
cd scripts
ls
vi backup_full.sh/
sudo vi backup_full.sh/
sudo vi backup_full.sh
chmod +x /opt/scripts/backup_full.sh
sudo vi backup_full.sh
ls
crontab -e
crontab -e
crontab -l
ls -lah /backup_dir
/opt/scripts/backup_full.sh /var/log /backup_dir
ls -l /opt/scripts/backup_full.sh
chmod +x /opt/scripts/backup_full.sh
ls -l /opt/scripts/backup_full.sh
chmod +x /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh /var/log /backup_dir
ls -lh /backup_dir
/opt/scripts/backup_full.sh /www_dir /backup_dir
ls -lh /backup_dir
crontab -e
exit
