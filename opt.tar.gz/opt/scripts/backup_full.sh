#!/bin/bash

show_help() {
    echo "Uso: $0 ORIGEN DESTINO"
    echo "Ejemplo: $0 /var/log /backup_dir"
    echo ""
    echo "Opciones:"
    echo "  -help    Muestra esta ayuda"
}

if [ "$1" = "-help" ]; then
    show_help
    exit 0
fi

if [ $# -ne 2 ]; then
    echo "Error: debe indicar ORIGEN y DESTINO"
    show_help
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"
FECHA=$(date +%Y%m%d)

if [ ! -d "$ORIGEN" ]; then
    echo "Error: el origen no existe o no es un directorio: $ORIGEN"
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: el destino no existe o no es un directorio: $DESTINO"
    exit 1
fi

if ! mountpoint -q "$DESTINO"; then
    echo "Error: el destino no está montado: $DESTINO"
    exit 1
fi

if ! df "$ORIGEN" > /dev/null 2>&1; then
    echo "Error: el sistema de archivos de origen no está disponible"
    exit 1
fi

NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

tar -czf "$DESTINO/$ARCHIVO" -C "$(dirname "$ORIGEN")" "$NOMBRE"

if [ $? -eq 0 ]; then
    echo "Backup creado: $DESTINO/$ARCHIVO"
else
    echo "Error: falló el backup"
    exit 1
fi
