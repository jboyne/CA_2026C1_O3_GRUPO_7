#!/bin/bash

if [ "$1" = "-help" ]; then
    echo "Uso: $0 origen destino"
    exit
fi

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)

if [ ! -d "$ORIGEN" ]; then
    echo "Origen inexistente"
    exit
fi

if [ ! -d "$DESTINO" ]; then
    echo "Destino inexistente"
    exit
fi

NOMBRE=$(basename $ORIGEN)

tar -czf $DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz $ORIGEN

echo "Backup realizado"
